<?php
require 'UsuarioOld.class.php';

$listar = [
    ['id' => $id, 'nome' => $nome,]
];

foreach ($listar as $listar) {
    echo "ID: " . $listar['id'] . "<br>";
    echo "Nome: " . $listar['nome'] . "<br><br>";
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Usuarios</title>
</head>
<body>
    
</body>
</html>