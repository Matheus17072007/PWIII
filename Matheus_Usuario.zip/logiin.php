<?php
require 'Usuario.class.php'

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Nunito+Sans:opsz,wght@6..12,300&family=Poppins:wght@200&display=swap');
        *{
          margin: 0;
          padding: 0;
          font-family: Arial, Helvetica, sans-serif;
        }

        .cadastro{
            background-color: rgb(255, 255, 255);
            position: absolute;
            left: 50%;
            top: 57%;
            transform: translate(-50%,-50%);
            border: 3px solid black;
            padding: 140px;
            border-radius: 20px;
            width: 370px;
            height: 348px;
           
        }

        h1{
            font-size: 60px;
            font-family: 'Nunito Sans', sans-serif;
            font-family: 'Poppins', sans-serif;
            font-weight: bold;
            position: relative;
            top: -6vw;
            left: 3vw;
            color: rgb(228, 154, 16);
        }

        h2{
            font-family: 'Nunito Sans', sans-serif;
            font-family: 'Poppins', sans-serif;
            font-weight: bold;
            font-size: 22px;
            right: 6vw;
            position: relative;
            top: -1.2vw;

        }

        .input{
            outline: none;
            border: 0;
            outline: none;
            border: 0;
            position: relative;
            top: -3.2vw;
            height: 29px;
            border-radius: 5px;
            width: 400px;
            left: 1vw;
            background-color: rgba(192, 192, 192, 0.764);
            border: 2px solid black;
        }

        .cadastrar{
            background-color: #6EA1EB;
            color: white;
            border-radius: 5px;
            height: 60px;
            width: 110px;
            font-size: 25px;
            font-family: 'Nunito Sans', sans-serif;
            font-family: 'Poppins', sans-serif;
            font-weight: bold;
            width: 185px;
            position: relative;
            top: 1vw;
            left: 6vw;
            padding: 10px;

        }

        .cadastrar:hover{
            cursor: pointer;
            transition: 2s;
            background-color: rgb(228, 154, 16);
        }



        .part1{
            background-color: rgb(228, 154, 16);
            height: 80px;
            
        }

        .smile{
            width: 140px;
            position: relative;
            left: 6vw;
            top: 0.5vw;
        }

        .casaIcon{
            height: 90px;
            position: relative;
            left: 90%;
            top: 36vw;
        }
        
    </style>
</head>
<body>
    <div class="part1">
        <img class="smile" src="img/smile.png" alt="">
    </div>
    <div class="cadastro">
        <form action="teste1.php" method="post">

            <h1>Login</h1>
            <h2>Nome</h2>
            <input class="input" type="text" name="nome" placeholder="Insira seu nome completo">
            <h2>Email</h2>
            <input class="input" type="text" name="email" placeholder="Insira seu email">
            <h2>Senha</h2>
            <input class="input" type="password" name="senha" placeholder="Insira uma nova senha">

            <input class="cadastrar" type="submit" value="Entrar">

        </form>
        

    </div>

    <a href="index.html"><img class="casaIcon" src="img/casa-icon.png" alt=""></a>
    
</body>
</html>