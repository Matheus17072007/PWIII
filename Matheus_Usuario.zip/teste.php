<?php
require 'Usuario.class.php';

if (isset($_POST['nome'])) {

    $nome  = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $usuario = new Usuario();

    $chk = $usuario->chkUser($email);


    if($chk){
        echo "<script>
                alert ('Usuário já existe')
            </script>";      
    }else {
        $cadastrar = $usuario->cadastrar($nome, $email, $senha);
        if($cadastrar) {
            echo "<script>
                alert ('Usuário cadastrado com sucesso')
            </script>";
        }else{

    }
}

}

