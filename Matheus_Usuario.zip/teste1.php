<?php
require 'Usuario.class.php';

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];

$usuario = new Usuario();

$chk = $usuario->chkUser($email);

if($chk) {
    echo "<script>
            alert ('Bem vindo ao seu perfil')
        </script>";
}else{
    echo "<script>
            alert ('Usuário ou senha incorretos')
        </script>";
}



?>